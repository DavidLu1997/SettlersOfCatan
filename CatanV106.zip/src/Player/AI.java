package Player;

//AI class, extends player and adds AI methods
//Programmed primarily by: David Lu
public class AI extends Player {

	//Performs next move
	public void getMove()
	{
		
	}
}
