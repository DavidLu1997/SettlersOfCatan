//Enum for resources
package Card;
public enum Resource {
	BRICK, WOOD, STONE, WHEAT, SHEEP
}
