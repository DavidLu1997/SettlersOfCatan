package Building;

//Type of building
public enum buildingType {
	ROAD, SETTLEMENT, CITY
}
