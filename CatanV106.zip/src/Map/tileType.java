package Map;

//Types of tiles
public enum tileType {
	HILL, PASTURE, MOUNTAIN, FIELD, FOREST, DESERT
}