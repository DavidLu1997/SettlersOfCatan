package Map;

//Type of location
public enum locationType {

	TILE, EDGE, VERTICE;
}
